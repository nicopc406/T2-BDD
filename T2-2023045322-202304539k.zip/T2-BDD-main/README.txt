- Tarea 2
------------------

- 1. Integrantes:

* Nombre: Javier Rojas Ll.
* ROL: 202304532-2

* Nombre: Nicolás Pérez
* ROL: 202304539-k

--------------------

- 2. Instrucciones de Ejecución:

Para ejecutar bien la Base de Datos y los .php tienen que:

1. Base de Datos:

* Abre phpMyAdmin
* Abre el archivo TablasyTriggers.sql
* Manualmente copia y pega el achivo en la seccion SQL de phpMyAdmin

Eso automáticamente crea toda la Base de Datos y también realiza los INSERT correspondientes

2.  Archivos .php:

* Copia la carpeta principal del proyecto en el directorio /var/www/html/"Nombre de la carpeta de destino"

Una vez hecho eso los .php estarán listos para arrancar la pagina Web

3.  Servidor:
    
* Inicia los servicios de Apache y MySQL para que todo funcione en orden

4.  Acceso:

* Abre tu navegador web y accede a: 
    
    http://localhost/"Nombre de la carpeta donde guardaste los datos"/Page.php

Esto te redirigirá a Login.php donde podrás iniciar sesión con uno de los usuarios creados en el ISERT o crear un nuevo usuario
-----------------------------------

- 3. Elementos SQL Implementados:

La base de datos utiliza los siguientes elementos:

* View: Vista_Solicitudes

* Procedimiento almacenado: SP_Crear_Solicitud_Error

* Triggers: Max20, Max2, Min3, Titulo20min, TR_Asignacion_Automatica

* Función SQL: ContarIngenieros

---------------------

- 4. Supuestos:

* Durante la ejecución de la revisión se asume que se utilizo Linux Ubuntu para ejecutar todo el proceso, también asumimos que se siguieron los pasos correctamente y que se utilizan casos estándar para la inserción de datos y/o trabajo en la pagina

